# Production Tetragon Configuration — Threat-Informed

RHEL 9 / kernel 5.14 / Tetragon v1.6.0

## Contents
- policies/          7 TracingPolicy files → /etc/tetragon/tetragon.tp.d/
- tetragon.conf.d/   3 config drop-ins    → /etc/tetragon/tetragon.conf.d/
- splunk/            12 detections + 1 correlation search (MITRE-mapped)
- docs/              Threat coverage & deployment reference

## Deploy order
1. Read docs/Tetragon-Threat-Coverage.docx (§5 deployment, §4 known bugs)
2. Validate hooks on target kernel (§5.2)
3. Ring 0 canary in AUDIT mode (05-enforcement as Post, not Sigkill)
4. Tune exclusion lists, confirm drop metrics clean
5. Stage to enforce per §5.3

## Critical rules (do not violate)
- NEVER remove the NotIn/NotPrefix/NotPostfix guards on /var/log selectors
  (feedback loop → CPU spike)
- NEVER enable enable-process-ns (system hang)
- 05-enforcement AUDIT-FIRST always; never enforce on build/CI hosts
