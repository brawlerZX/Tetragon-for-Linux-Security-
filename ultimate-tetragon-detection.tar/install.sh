#!/usr/bin/env bash
set -euo pipefail
echo "== Validating hooks =="
fail=0
[ -e /sys/kernel/tracing/events/raw_syscalls/sys_enter ] || { echo "MISSING raw_syscalls/sys_enter"; fail=1; }
for s in security_file_permission security_path_truncate security_bprm_check; do
  grep -qw "$s" /proc/kallsyms || { echo "MISSING symbol: $s"; fail=1; }
done
[ "$fail" = 0 ] && echo "  all hooks present" || { echo "  ABORT"; exit 1; }
echo "== Installing =="
sudo mkdir -p /etc/tetragon/tetragon.tp.d /etc/tetragon/tetragon.conf.d
sudo cp etc/tetragon/tetragon.conf.d/* /etc/tetragon/tetragon.conf.d/
sudo cp etc/tetragon/tetragon.tp.d/*.yaml /etc/tetragon/tetragon.tp.d/
echo "== Restarting =="
sudo systemctl restart tetragon; sleep 2
tetra tracingpolicy list || true
echo "Done. Detection-only — all 9 policies observe, none enforce."
