# Tetragon ULTIMATE Detection Configuration

**Platform:** RHEL 9 / kernel 5.14 / Tetragon v1.6.0
**Mode:** DETECTION ONLY — no enforcement anywhere (every action is Post)
**This is the single authoritative detection config.**

Covers the current Linux threat set AND the exploitation footprint of major
kernel-LPE vulnerability classes (Dirty Pipe, Dirty COW, nf_tables/Flipping
Pages, Looney Tunables, PwnKit, fileless memfd, container escape), plus a
CVE-agnostic "unprivileged became root" detection that generalizes to unknown
and future vulnerabilities.

## The one concept to understand
Tetragon detects BEHAVIOR, not vulnerabilities. It does not see "the Dirty
Pipe bug" — it sees the exploitation footprint (splice usage, a SUID binary
getting overwritten, an unprivileged login running as root). See
docs/Ultimate-Detection-Coverage.docx Section 1. Use this framing in review.

## Layout
```
etc/tetragon/
├── tetragon.conf.d/   enable-process-cred, enable-ancestors, metrics-server
└── tetragon.tp.d/
    ├── 01-file-content-capture.yaml    full-buffer write on ~11 critical files
    ├── 02-file-integrity.yaml          rootkit/persistence/log-tamper (metadata)
    ├── 03-credential-access.yaml       shadow/key reads (LSM)
    ├── 04-network-threat.yaml          miner/TOR/webshell/reverse-shell
    ├── 05-syscall-tracepoint.yaml      module/ptrace/container-breakout (1 TP)
    ├── 06-privilege-escalation.yaml    setid/capset/user-ns
    ├── 07-staging-execution.yaml       exec from /tmp,/dev/shm; netcat (DETECT)
    ├── 08-exploit-behavior.yaml        Dirty Pipe class / nf_tables / fileless
    └── 09-process-anomaly.yaml         interpreter spawn; LPE outcome
splunk/detections.spl                   18 detections + 2 correlation searches
docs/Ultimate-Detection-Coverage.docx   the vulnerability-detection model
docs/Tetragon-Threat-Coverage.docx      threat model + MITRE matrix + known bugs
docs/Tetragon-Lightweight-Architecture.docx  hook-choice reasoning
```

## Deploy
```bash
bash install.sh        # validates hooks, installs, restarts, verifies
```
All policies are detection-only, so there is no audit-then-enforce step.

## Highest-value detection: D13
The auid!=euid=0 search detects the OUTCOME every privilege-escalation exploit
shares — an unprivileged login running as root — regardless of which CVE was
used. This is what extends coverage to unknown/future vulnerabilities. Tune it
with an allowlist of auids that legitimately sudo to root before alerting.

## Tuning priority after load
1. D13 — allowlist legitimate admin sudo (auid -> root) paths.
2. D17 — set primitive-burst thresholds for your workload.
Everything else is high-signal by design.

## Critical rules (unchanged from production config)
- Never remove /var/log exclusion guards in 02 (feedback loop -> CPU spike).
- Never enable enable-process-ns (host hang).
- Detection is not prevention — patch first; this is the patch-gap safety net.
